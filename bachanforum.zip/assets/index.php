<?php
header("Location: ../404");
?>